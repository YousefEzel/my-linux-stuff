# ddos-script
All  things to do after installing Kali Linux and Add more awesome hacking tools to your Kali Linux system

Change log v5.0:
+ add install dvwa
+ add install bwapp

Change log v4.5:
+ fix sound mute and enable pulseaudio run startup
+ install latest virtualbox, virtualbox-ext-pack and fix unable connect usb to virtualbox and fix "Kernel driver not installed (rc=-1908)"
+ add google-chrome installation
+ update latest tor browser
+ add install metasploit, aircrack-ng on ubuntu/linux mint
+ add netripper tool for sniff https password
+ add fluxion tool

Change log v4.1:
+ Add Kali Linux 2.0 repository for installing more package
+ Add "Update kali linux Sana to Kali linux 2016.2" option
+ Add "how to install wireless driver in your kali linux 2016.2 system" option
+ Add "Transparent-top bar-notification-windows on Kali Linux" option


Change log v4:
- change source.list kali linux rolling
- modify video tutorial links
- add more tool ;)
- add vmware-tools

Website: http://kali-linux.co
Facebook Fanpage: https://www.facebook.com/haking.cracking.tutorial

Review ddos script: https://youtu.be/KZHg_xcK2fA

Contact: https://www.youtube.com/c/penetrationtestingwithddos
